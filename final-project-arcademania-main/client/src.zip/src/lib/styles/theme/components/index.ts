import { Button } from "./button";

export const components = {
  Button,
};
