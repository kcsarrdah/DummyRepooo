// import Home from "lib/components/home/Home";
import Home from "../lib/components/home/Home";

export default Home;
