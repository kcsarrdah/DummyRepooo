import ErrorPage404 from "../lib/components/404/ErrorPage404";

/**
 * NextJS page to render 404.
 */
export default ErrorPage404;
